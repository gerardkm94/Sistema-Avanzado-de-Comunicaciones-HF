function txBits = sourceTx(systemParam)
   
%Para bpsk de 0 a 1
   % txBits = randi([0,1],1,systemParam.nDataBits);
   txBits = randi([0,3],1,systemParam.nDataBits);
    
end