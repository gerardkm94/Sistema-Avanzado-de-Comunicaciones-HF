function rxBits = decoder(systemParam,rxBitsEncoded) 

    sizetxBits=length(rxBitsEncoded);
    rxBits=zeros(sizetxBits/2,1);
    contador = 1;
    for i=1:2:sizetxBits
        
        if rxBits(i)==0 
            
           rxBits(contador)= 0; 
           rxBits(contador+1)= 0;
            
        elseif rxBits(i)==1
            
            rxBitsEncoded(contador)= 0;
            rxBitsEncoded(contador+1)= 1;
            
        elseif rxBits(i)==2
            
            rxBitsEncoded(contador)= 1;
            rxBitsEncoded(contador+1)= 0;
            
        elseif rxBits(i)==3
            
            rxBitsEncoded(contador)= 1;
            rxBitsEncoded(contador+1)= 1;
            
        end
       contador = contador +1;
    end
end
