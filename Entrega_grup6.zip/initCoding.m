function systemParam = initCoding(systemParamIn)

%% Keep existing system parameters 
% Guardamos la entrada de la funcion en la variable local asi no se 
% pierden los valores existentes de la variable
systemParam = systemParamIn;
%% Define new system parameters
%Defino esta variable para tener un booleano de inicializacion y 
%desactivarlo cuando la entrada de parametros no sea correcta.
systemParam.coding.enabled = true;
%% Initialize system
% Coding type {'fast','slowWeak','slowStrong','none'}

if strcmp(systemParam.coding.type,'fast')

elseif strcmp(systemParam.coding.type,'slowWeak')
        disp('1');
elseif strcmp(systemParam.coding.type,'slowStrong')
        disp('2');
elseif strcmp(systemParam.coding.type,'none')
        disp('3'); 
else
      systemParam.coding.enabled=false;
end            
%% Show new parameters
if systemParam.coding.enabled
    disp('-- Coding configuration ----------------------------------------------')
    disp(['Coding Type : ' num2str(systemParam.coding.type)]);
else
        error('The introduced type is not correct, please, insert it again');
    
end

end

