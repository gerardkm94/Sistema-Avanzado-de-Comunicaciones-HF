function systemParam = initInterleaving(systemParamIn)

%% Keep existing system parameters 
% Guardamos la entrada de la funcion en la variable local asi no se 
% pierden los valores existentes de la variable
systemParam = systemParamIn;
%% Define new system parameters
%Defino esta variable para tener un booleano de inicializacion y 
%desactivarlo cuando la entrada de parametros no sea correcta.
systemParam.interleaving.enabled = true;
%% Initialize system
% Interleaving type {'Deep','Shallow','None'}

if strcmp(systemParam.interleaving.type,'Deep')
        disp('2');
elseif strcmp(systemParam.interleaving.type,'Shallow')
    %Recordarme que os comente una cosa aquí
        disp('5');
elseif strcmp(systemParam.interleaving.type,'none')
        disp('3'); 
else
      systemParam.interleaving.enabled=false;
end            
%% Show new parameters
if systemParam.interleaving.enabled
    disp('-- Interleaving configuration ----------------------------------------------')
    disp(['Interleaving Type : ' num2str(systemParam.interleaving.type)]);
else
        error('The introduced Interleaving type is not available, please, insert it again');
    
end