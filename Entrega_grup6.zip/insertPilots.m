function pilots = insertPilots(systemParam)

    pilots(systemParam.ofdm.indexPilotSc, :) = 1; 

end